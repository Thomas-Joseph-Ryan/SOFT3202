package au.edu.sydney.soft3202.task1.model;

public record Item(String item, int count, Double cost) {
}
