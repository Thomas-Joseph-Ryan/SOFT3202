package au.edu.sydney.soft3202.task1;

import au.edu.sydney.soft3202.task1.model.ShoppingBasket;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNull;

public class ShoppingBasketTest {

    ShoppingBasket shoppingBasket;

    @BeforeEach
    public void setUp() {
//        shoppingBasket = new ShoppingBasket();
    }


}


