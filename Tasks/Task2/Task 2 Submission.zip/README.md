# Bonus points (Change to Yes to indicate you are applying for bonus.)

1. 5 Bonus marks if you implement a property based (single) test case that can test whether any of the provided users can add and delete arbitrary item names, and for each item name, arbitrary number of items can be added and removed so long as the count is with in 0 and INT_MAX. (Maximum as before will be 25 marks)

No

# To run the server

```
gradle bootRun
```

